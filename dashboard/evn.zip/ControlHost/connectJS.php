<?php
// começar ou retomar uma sessão
define('HOST', 'localhost');
// define('HOST', '162.241.2.98');
define('USUARIO', 'plataf69_admin');
define('SENHA','admin');
define('DB', 'plataf69_somar');

$opcoes = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8');
$conexao = new PDO("mysql:host=".HOST."; dbname=".DB, USUARIO, SENHA, $opcoes);
