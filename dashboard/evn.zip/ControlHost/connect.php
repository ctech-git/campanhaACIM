<?php
// começar ou retomar uma sessão
define('HOST', 'localhost');
// define('HOST', '162.241.2.98');
define('USUARIO', 'plataf69_admin');
define('SENHA','admin');
define('DB', 'plataf69_somar');

$conexao = mysqli_connect(HOST,USUARIO,SENHA,DB) or die('Nao foi possivel conectar');
