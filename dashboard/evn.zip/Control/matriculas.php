<?php
// A sample PHP Script to POST data using cURL
// Data in JSON format
$id = $_GET['id'];

$data = array(
    'query' => 'query {
        matriculas(pessoaID:'.$id.'){
          nodes{
              id...
              on Matricula{
                pessoaID,
                registroAluno,
                data,
                situacao,
                chamada,
                boletim{
                    frequenciaGlobal,
                    registros{
                      disciplinaID
                        frequencia,
                        colunas{
                          nome,
                          valor
                          }
                      }
                }
              }
            }
          }
          }
'
);

$payload = json_encode($data);

// Prepare new cURL resource
$ch = curl_init('https://api-evn.controller.education/graphql/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

// Set HTTP Header for POST request
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Authorization: Bearer VBW5pLzfaQtjJg6d29yPdyWz7OMRAp4f'
));

// Submit the POST request
$result = curl_exec($ch);
echo $result;

// Close cURL session handle
curl_close($ch);

?>
